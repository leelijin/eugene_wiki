<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['allowrename']           = '문서의 이름을 바꿀 수 있는 그룹 및 사용자. (쉼표로 구분)';
$lang['minor']                 = '링크 조절을 사소한 바뀜으로 표시하겠습니까? 사소한 바뀜은 RSS 피드와 구독 메일에 나열되지 않을 것입니다.';
$lang['autoskip']              = '기본적으로 이름공간 이동에서 오류를 자동으로 건너뛰도록 활성화합니다.';
$lang['autorewrite']           = '기본적으로 이름공간을 이동하고 나서 자동으로 링크 다시 쓰기를 활성화합니다.';
