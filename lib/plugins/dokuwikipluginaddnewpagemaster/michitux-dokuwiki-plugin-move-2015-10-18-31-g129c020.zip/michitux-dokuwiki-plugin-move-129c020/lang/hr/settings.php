<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['allowrename']           = 'Omogući preimenovanje stranica ovim grupama i korisnicima (zarezom odvojena lista).';
$lang['minor']                 = 'Označiti prilagodbe poveznica kao manje značajne? Takve promjene neće biti prikazane u RSS obavijestima i obavijesnim porukama.';
$lang['autoskip']              = 'Omogući kao podrazumijevano automatsko preskakanje grešaka pri premještanju imenskog prostora.';
$lang['autorewrite']           = 'Omogući kao podrazumijevano automatsku prilagodbu poveznica.
';
