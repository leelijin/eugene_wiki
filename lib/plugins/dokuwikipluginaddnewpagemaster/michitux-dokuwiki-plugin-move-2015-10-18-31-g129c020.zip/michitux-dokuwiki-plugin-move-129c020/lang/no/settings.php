<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Daniel Raknes <daniel.raknes@gmail.com>
 */
$lang['allowrename']           = 'Tillatt navenendring på disse sidene for disse gruppene og brukerne (separert med komma)';
$lang['minor']                 = 'Merk lenkejusteringer som liten endring? Små endringer vil ikke bli listet i RSS eller varslet til de som abonnerer på endringseposter. ';
$lang['autoskip']              = 'Tillatt automatisk ignorering av feil i navnerom som standard.';
$lang['autorewrite']           = 'Tillatt automatisk lenkeoppdatering etter flytting av navnerom som standard.';
