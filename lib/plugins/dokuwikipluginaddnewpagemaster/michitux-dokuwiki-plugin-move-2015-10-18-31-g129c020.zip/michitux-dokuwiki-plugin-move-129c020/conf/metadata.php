<?php

$meta['allowrename'] = array('string');
$meta['minor'] = array('onoff');
$meta['autoskip'] = array('onoff');
$meta['autorewrite'] = array('onoff');
